Download group_16_assignment6 folder.
Extract all. 
Open assignment6.pde and press run. 
To generate additional clouds, press mouse. 
Place assignment5.pde, House.pde, player.pde, scepter.pde, soccer.jpg, 
grass.jpg, data folder, and lotus folder in the same folder. Press run on
group_16_assignment5.pde to display animation.